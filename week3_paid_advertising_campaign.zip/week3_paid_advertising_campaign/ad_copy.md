# Ad Copy and Creative Briefs

## Google Search — Ad 1
**Headlines**
- Build a Simple Skincare Routine
- Get Your Free 7-Day Checklist
- Small Steps, Happier Skin
- Simple Self-Care Starts Here
- Bloom & Bare Skincare

**Descriptions**
- Start small with a practical 7-day checklist for your daily skincare habits. Get yours by email.
- Make self-care feel simpler with Bloom & Bare. Sign up for the free checklist today.

**Display URL:** bloombare.example/checklist  
**CTA:** Sign up

## Google Display — Creative A
- **Headline:** Make Skincare Feel Simple
- **Body:** A small daily checklist to help you build a routine that works for you.
- **CTA:** Get the Free Checklist
- **Visual:** cream background, muted green botanical line art, checklist card, clear readable text.
- **Alt text:** Preview of a seven-day simple skincare checklist.

## Meta/Facebook — Ad 1
**Primary text:** Skincare doesn't have to feel complicated. 🌿 Get our free 7-Day Simple Skincare Checklist and make room for a few small, feel-good habits.  
**Headline:** Your Simple Skincare Reset  
**Description:** A free checklist delivered by email.  
**CTA:** Sign Up

## Meta/Facebook — Ad 2
**Primary text:** One small step at a time. Build a skincare routine that feels manageable with Bloom & Bare's free 7-day checklist.  
**Headline:** Keep Self-Care Simple  
**Description:** Get the checklist and start today.  
**CTA:** Sign Up

## Creative testing matrix
| Test | Variant A | Variant B | Success metric |
|---|---|---|---|
| Hook | “Skincare made simple” | “One small step a day” | Landing-page conversion rate |
| Visual | Checklist preview | Botanical illustration | Cost per lead + lead quality |
| CTA | “Get the checklist” | “Sign up free” | Signup rate |

No ad should imply guaranteed results or make unsupported medical/dermatological claims.
