# Week 3 Mini Project — Paid Advertising Campaign
**Brand:** Bloom & Bare (fictional skincare/self-care brand)  
**Project type:** Campaign plan + landing page prototype + tracking plan + performance report

## What's included
- `campaign_plan.md` — Google Search, Google Display, and Facebook/Meta campaign setup plan
- `landing_page.html` — responsive landing page with lead-capture form prototype
- `tracking_analytics.md` — GA4 event and conversion setup plan
- `campaign_performance_report.md` — clearly labelled sample/simulated performance report
- `campaign_data.csv` — sample campaign performance data
- `ad_copy.md` — ad copy and creative briefs
- `audience_plan.md` — custom audience and targeting plan
- `lead_capture.csv` — sample lead tracker template

## Important implementation note
This is a portfolio-ready campaign plan and working front-end prototype. No live advertising account, audience list, or Google Analytics property has been connected or charged. Performance data is **simulated for demonstration**, not actual campaign results. To run it live, publish the landing page, connect a form backend/CRM, create the campaigns in Google Ads and Meta Ads Manager, and add the real GA4 Measurement ID.

## Suggested submission
Share the GitHub repository containing these files, or publish `landing_page.html` using GitHub Pages and submit that public page URL along with the repository.
