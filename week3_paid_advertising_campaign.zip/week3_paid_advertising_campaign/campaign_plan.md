# Paid Advertising Campaign Plan — Bloom & Bare

## 1. Campaign objective
Generate qualified email leads for a fictional, gentle-skincare brand by offering a free **7-Day Simple Skincare Checklist**.

**Primary conversion:** checklist signup (lead form submission)  
**Secondary conversions:** landing-page view, CTA click, engaged session  
**Campaign duration:** 14 days  
**Illustrative total budget:** ₹14,000 (₹1,000/day); proposed allocation below.

## 2. Budget allocation (planned)
| Channel | Campaign | Budget | Daily average | Purpose |
|---|---|---:|---:|---|
| Google Search | Non-brand high-intent keywords | ₹5,600 | ₹400 | Capture active search demand |
| Google Display | Contextual/remarketing test | ₹2,800 | ₹200 | Build awareness and bring visitors back |
| Meta/Facebook | Lead magnet campaign | ₹5,600 | ₹400 | Reach relevant interest/lookalike-style audiences |
| **Total** | | **₹14,000** | **₹1,000** | |

## 3. Google Search campaign
**Campaign name:** BB_Search_SkincareChecklist_India  
**Objective:** Leads  
**Network:** Google Search only for initial test; disable Display expansion in this campaign.  
**Location:** India, narrowed to serviceable areas once the brand's fulfilment geography is confirmed.  
**Language:** English; add regional-language ad groups only after validating landing-page support.

### Ad groups and keyword themes
- **Simple skincare routine:** “simple skincare routine”, “beginner skincare routine”
- **Gentle skincare:** “gentle skincare tips”, “skincare for beginners”
- **Checklist intent:** “daily skincare checklist”, “skincare routine checklist”

Use exact and phrase match at launch. Review search terms frequently and add irrelevant queries as negative keywords. Avoid medical claims or promises to treat skin conditions.

**Example negative keywords:** jobs, salary, course, wholesale, free samples (if not offered), treatment, cure.

### Example responsive search ad
Headlines:
1. Build a Simple Skincare Routine
2. Get Your Free 7-Day Checklist
3. Small Steps, Happier Skin
4. Simple Self-Care Starts Here
5. A Routine That Feels Manageable

Descriptions:
- Start small with a practical 7-day checklist for your daily skincare habits. Get yours by email.
- Make self-care feel simpler. Sign up for the free Bloom & Bare checklist today.

## 4. Google Display campaign
**Campaign name:** BB_Display_Checklist_Awareness  
**Objective:** Awareness/website traffic initially; optimize to leads only after enough conversion data exists.  
**Budget:** ₹2,800 for 14 days.  
**Creative sizes:** 1200×628 landscape, 1080×1080 square, 300×250 medium rectangle, 728×90 leaderboard.  
**Creative concept:** soft botanical shapes, product-neutral imagery, headline “Make skincare feel simple”, CTA “Get the free checklist”.  
**Targeting:** contextual wellness/skincare content and, where eligible, consented site-visitor remarketing. Exclude mobile apps/placements with poor quality and monitor placement reports.  
**Frequency:** use frequency controls where available; review reach and frequency.

## 5. Facebook/Meta campaign
**Campaign name:** BB_Meta_LeadMagnet_14D  
**Objective:** Leads (website conversion event or instant form; website form preferred for consistent measurement).  
**Budget:** ₹5,600 over 14 days.  
**Placements:** Advantage+ placements initially; review performance by placement.  
**Creative:** 4:5 or 1:1 simple graphic, friendly checklist preview, short copy, one CTA.  
**Audience tests:**
- **Ad set A — Broad:** adults in confirmed shipping/service area; broad targeting with creative-led discovery.
- **Ad set B — Interests:** skincare, beauty, personal care, self-care (availability varies by account and region).
- **Custom audience:** people who visited the site or engaged with the brand's Instagram/Facebook page, only where consent, platform rules, and sufficient audience size permit.
- **Lookalike audience:** optional only if the account has an eligible source audience and Meta makes the feature available. Do not upload purchased or scraped contact lists.

## 6. Funnel
1. Ad impression → 2. Ad click → 3. Landing page view → 4. Form start → 5. Successful signup → 6. Thank-you state / email delivery.
Keep message consistent from ad to landing page. Ask only for an email address; link a privacy notice before collecting real data.

## 7. Optimization rules
- Wait for enough data before making large decisions; do not overreact to one day.
- Review search terms and placements at least twice weekly.
- Compare cost per lead (CPL), conversion rate, and lead quality, not clicks alone.
- Pause a creative only after it has enough delivery to make the comparison meaningful.
- Keep tracking and consent settings consistent with local privacy requirements and platform policies.
