# Google Analytics 4 and Conversion Tracking Plan

## Before launch
1. Create or select the correct GA4 property and web data stream.
2. Install the official Google tag using the site's tag implementation or Google Tag Manager.
3. Replace the placeholder Measurement ID in the landing-page comments/configuration with the real `G-XXXXXXXXXX` ID.
4. Configure consent messaging and only activate optional analytics/advertising tags as permitted by user consent and applicable requirements.
5. Verify in GA4 Realtime and DebugView before spending on ads.

## Recommended events
| Event | Trigger | Key parameters | Mark as key event? |
|---|---|---|---|
| `page_view` | Landing page loads | page_location, page_title | No |
| `cta_click` | Main CTA clicked | placement, campaign | No |
| `form_start` | Email form first interacted with | form_id | No |
| `generate_lead` | Valid form submitted successfully | form_id, lead_magnet | **Yes** |
| `thank_you_view` | Confirmation state shown | source | Optional |

Use GA4's recommended `generate_lead` event for a successful lead submission. Do not send email addresses or other personally identifiable information to GA4.

## UTM naming
Example landing page URL:
`https://your-domain.example/?utm_source=facebook&utm_medium=paid_social&utm_campaign=bb_checklist_14d&utm_content=creative_a`

Google Search example:
`?utm_source=google&utm_medium=cpc&utm_campaign=bb_search_checklist&utm_content=rsa_a`

## Validation checklist
- [ ] Landing page works on mobile and desktop.
- [ ] Form validation prevents blank/invalid email submission.
- [ ] Successful signup is recorded once, not on every page refresh.
- [ ] GA4 Realtime shows test events.
- [ ] Ads platform conversion diagnostics show the event after test traffic.
- [ ] Consent, privacy notice, and data retention are reviewed.
- [ ] UTMs are consistent and do not contain personal data.

**Important:** The included landing page is a front-end prototype. It does not store or email leads until connected to a secure form backend/CRM. The GA4 ID is a placeholder; no real analytics property is connected in this demo.
