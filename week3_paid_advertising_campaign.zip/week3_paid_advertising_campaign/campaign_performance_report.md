# Campaign Performance Report — 14-Day Demonstration

> **Data status: SIMULATED.** These figures are illustrative sample data for the assignment, not live campaign results. Replace them with exported data after the campaigns run.

## Executive summary
The example campaign generated 120 simulated leads from 4,000 impressions and 600 clicks. With a proposed ₹14,000 budget and simulated spend of ₹12,000, the overall cost per lead (CPL) is ₹100. The best simulated CPL is from Meta, while Search has the highest simulated click-through rate among the three channels.

## Results by channel (simulated)
| Channel | Spend | Impressions | Clicks | Leads | CTR | CPC | Conversion rate | CPL |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Google Search | ₹4,800 | 20,000 | 400 | 48 | 2.00% | ₹12.00 | 12.00% | ₹100.00 |
| Google Display | ₹2,200 | 40,000 | 120 | 12 | 0.30% | ₹18.33 | 10.00% | ₹183.33 |
| Meta/Facebook | ₹5,000 | 50,000 | 500 | 60 | 1.00% | ₹10.00 | 12.00% | ₹83.33 |
| **Total** | **₹12,000** | **110,000** | **1,020** | **120** | **0.93%** | **₹11.76** | **11.76%** | **₹100.00** |

## Interpretation
- Meta provides the lowest simulated CPL (₹83.33) and the largest lead count in this example.
- Search has the highest simulated CTR (2.00%), suggesting stronger intent among people who click.
- Display has the lowest CTR and highest CPL in this example; check placements, audience relevance, and creative before deciding whether to reduce spend.
- Total spend is ₹12,000, below the proposed ₹14,000 budget; this could reflect pacing or under-delivery in a real campaign.

## Recommendations
1. Validate conversion tracking before evaluating performance.
2. Shift budget gradually toward channels with lower CPL **only after checking lead quality**.
3. Review Search query reports and add irrelevant terms as negatives.
4. Test two creative hooks and keep the offer consistent.
5. Review landing-page speed, mobile usability, and form completion.
6. Report qualified leads and downstream outcomes, not only form submissions.

## Definitions
- **CTR** = clicks ÷ impressions × 100
- **CPC** = spend ÷ clicks
- **Conversion rate** = leads ÷ clicks × 100
- **CPL** = spend ÷ leads
