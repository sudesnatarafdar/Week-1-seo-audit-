# Audience and Targeting Plan

## Audience segments
1. **Broad prospecting:** adults within confirmed delivery/service geography. Use broad targeting to avoid over-constraining the initial test.
2. **Interest test:** people with relevant skincare, beauty, personal-care, and self-care interests, where those options are available.
3. **Warm engagement:** website visitors and social account engagers, if eligible and privacy-compliant.
4. **Customer/lead exclusions:** exclude existing leads from acquisition campaigns where technically possible and appropriate.
5. **Lookalike test:** optional, only when the platform permits it and a sufficiently sized, lawfully collected source audience exists.

## Custom audience safeguards
- Use only first-party data collected with a clear purpose and appropriate notice/consent.
- Never use scraped, purchased, or sensitive personal data.
- Do not upload email lists without the required rights and notices.
- Set retention and deletion practices; restrict access to lead data.
- Follow current platform policies and applicable privacy laws.

## Test structure
Run prospecting and warm-audience campaigns separately so results can be compared. Keep creative and offer consistent during the first test, then test one variable at a time.
