# Engagement Metrics Guide

Enter real analytics after publishing. Blank fields are intentional; do not invent performance results.

- **Reach:** unique accounts that saw content.
- **Impressions:** total displays, including repeat views where reported.
- **Engagement rate by reach:** (likes + comments + shares + saves) ÷ reach × 100.
- **Click-through rate (CTR):** link clicks ÷ impressions × 100. Use the same denominator consistently across comparisons.
- **Email conversion rate:** email sign-ups ÷ landing-page visits × 100.

## Weekly review
1. Identify the three posts with the highest saves and shares.
2. Compare formats (carousel, reel, story, single image).
3. Record which CTA produced the most clicks or sign-ups.
4. Choose one thing to repeat and one thing to test next week.
5. Check comments and replies for audience questions that could become future content.
