# Week 2 Mini Project: Social Media Brand Campaign
## Brand: Bloom & Bare
**Campaign theme:** Small rituals. Real glow.  
**Brand concept:** A fictional, affordable plant-inspired skincare brand focused on simple routines and mindful self-care.  
**Campaign duration:** 2 weeks  
**Primary channels:** Instagram and Facebook  
**Goals:** Build awareness, encourage saves/shares, drive profile visits, and collect email sign-ups.

> This is a fictional practice brand. Replace the brand name/product details if your course requires a real brand.

## What's included
- `brand_page.md` — brand profile, bio, voice, audience, and visual direction
- `content_calendar.csv` — a 14-day schedule
- `post_copy.md` — copy and creative direction for all 15 posts
- `email_sequences.md` — 3 email sequences
- `engagement_tracker.csv` — metrics tracking template with formulas/instructions
- `index.html` — a simple campaign landing page mockup

## Campaign strategy
**Audience:** Young adults aged 18–30 who enjoy simple self-care routines and approachable skincare content.  
**Tone:** Warm, encouraging, clear, never judgmental.  
**Content pillars:**
1. Education — easy skincare habits and ingredient explainers
2. Community — polls, questions, and user routine prompts
3. Product storytelling — benefits and how-to-use content
4. Lifestyle — calming, realistic self-care moments
5. Conversion — email sign-up and starter-routine CTA

## Success metrics
Track reach, impressions, likes, comments, shares, saves, profile visits, link clicks, and email sign-ups. Calculate:
- Engagement rate by reach = (likes + comments + shares + saves) / reach × 100
- Click-through rate = link clicks / impressions × 100
- Email conversion rate = sign-ups / landing-page visits × 100

All performance figures should be entered from actual platform analytics; no results are fabricated in this template.
