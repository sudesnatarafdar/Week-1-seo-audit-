# Brand Page — Bloom & Bare

## Profile
**Name:** Bloom & Bare  
**Category:** Skincare & self-care  
**Tagline:** Small rituals. Real glow.  
**Audience:** People aged 18–30 who want an uncomplicated, calming skincare routine.

## Instagram bio
Simple skincare. Softer routines. 🌿  
Small daily rituals for your kind of glow.  
✨ Start with the 3-step routine  
↓ Get the beginner’s guide

## Brand voice
- Warm, calm, and encouraging
- Simple language; explain any skincare term
- Inclusive and realistic, never promise perfect skin
- Avoid medical claims and guaranteed results

## Visual direction
- Palette: sage green, cream, warm beige, muted peach
- Typography: clean sans-serif headings, readable body text
- Photography: natural daylight, textured towels, water, plants, product still-lifes
- Layout: generous whitespace, short headlines, high contrast for accessibility
- Format mix: carousels, single-image posts, story frames, reel covers

## Pinned posts
1. Start Here: the 3-step routine
2. Our approach: simple, consistent, kind
3. FAQs: how to build a routine without overcomplicating it

## Campaign CTA
“Save this for your next routine” for educational posts; “Tap the link in bio to get the beginner’s guide” for sign-up posts.
