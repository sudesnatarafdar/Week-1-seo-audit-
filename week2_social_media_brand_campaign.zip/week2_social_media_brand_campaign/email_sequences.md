# Three Email Sequences

## Sequence 1 — Welcome series (new subscribers)

### Email 1: Welcome to a simpler routine
**Send:** Immediately after sign-up  
**Subject:** Your simpler skincare routine starts here  
**Preview text:** A calm, practical place to begin.

Hi there,

Welcome to Bloom & Bare. We’re here to make skincare feel a little less complicated and a little more like a moment for yourself.

Start with the basics: cleanse gently, moisturise, and use broad-spectrum SPF during the day. Add new products gradually and follow their directions.

Your next step: download the beginner’s routine guide and choose one small habit to try this week.

Warmly,  
The Bloom & Bare team

**CTA:** Get the beginner’s guide

### Email 2: Keep the basics easy
**Send:** 2 days after Email 1  
**Subject:** You don’t need a 10-step routine  
**Preview text:** Consistency can start with three simple steps.

Hi there,

It’s easy to feel like you need a shelf full of products. You don’t have to start there.

Build a routine you can repeat, introduce new products one at a time, and pay attention to how your skin responds. If you experience persistent irritation, stop using the product and seek advice from a qualified professional.

Small, realistic steps are worth celebrating.

**CTA:** Review the 3-step checklist

### Email 3: Make it your own
**Send:** 4 days after Email 1  
**Subject:** Your routine should fit your real life  
**Preview text:** A few questions to help you stay consistent.

Hi there,

Your routine should work with your life, budget, and preferences. Keep the products you use regularly easy to find, check product directions, and give yourself permission to keep things simple.

What would help you most right now—understanding ingredients, organising your routine, or choosing a simple order? Reply and tell us.

Thanks for being here,  
The Bloom & Bare team

**CTA:** Explore routine tips

---

## Sequence 2 — Guide download follow-up

### Email 1: Here’s your guide
**Send:** Immediately after guide request  
**Subject:** Your beginner’s guide is ready  
**Preview text:** Save it and come back whenever you need it.

Hi there,

Thanks for requesting the Bloom & Bare beginner’s guide. Use it as a starting point, not a strict set of rules: follow product labels and adjust for your own needs.

**CTA:** Open the beginner’s guide

### Email 2: One change at a time
**Send:** 3 days after Email 1  
**Subject:** Try one small change this week  
**Preview text:** Simple beats overwhelming.

Hi there,

If you’re changing your routine, try introducing one new product at a time. That makes it easier to notice how your skin responds. Stop if irritation occurs and seek professional advice for ongoing concerns.

**CTA:** See the routine checklist

### Email 3: Tell us what you need
**Send:** 6 days after Email 1  
**Subject:** What should we make simpler next?  
**Preview text:** Help shape our next beginner-friendly tip.

Hi there,

We’re creating more practical guides and would love to know what you’d find useful. Which topic should we cover next: routine order, ingredient basics, or travel-friendly routines?

**CTA:** Share your topic suggestion

---

## Sequence 3 — Re-engagement

### Email 1: A gentle check-in
**Send:** After 30 days without engagement  
**Subject:** Still looking for simpler skincare?  
**Preview text:** Here are a few easy tips to revisit.

Hi there,

It’s been a little while, so we wanted to share a friendly reminder: your routine can be simple. Revisit our basics checklist whenever it’s useful, and take what works for you.

**CTA:** Revisit the basics

### Email 2: Choose what you want to hear
**Send:** 5 days after Email 1  
**Subject:** Pick the tips you’d like from us  
**Preview text:** More of what helps, less of what doesn’t.

Hi there,

Would you prefer short routine checklists, ingredient explainers, or mindful self-care prompts? Choose the topics you care about so our emails can be more useful to you.

**CTA:** Update email preferences

### Email 3: Your choice
**Send:** 7 days after Email 2  
**Subject:** Should we keep in touch?  
**Preview text:** You’re in control of your inbox.

Hi there,

We’d be happy to keep sharing simple, practical skincare content. If it’s no longer useful, you can unsubscribe using the link below. Either way, thanks for spending a little time with Bloom & Bare.

**CTA:** Explore recent tips

**Compliance note:** Include the business identity, a valid mailing address, and a working unsubscribe link in real campaign emails. Send only to people who have appropriately opted in and follow applicable email-marketing laws.
