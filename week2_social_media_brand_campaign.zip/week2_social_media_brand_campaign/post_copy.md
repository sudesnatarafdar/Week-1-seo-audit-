# 15 Social Media Posts

## Day 1 — Start with three steps
**Format:** Carousel  
**Content pillar:** Education  
**Caption:** A good routine doesn’t need ten products. Start simple: 1) gentle cleanse, 2) moisturise, 3) daytime SPF. Keep it consistent, then adjust to your skin’s needs. Save this beginner-friendly checklist for later. 🌿  
**Creative direction:** Slides: 1 bold title; 2 cleanse; 3 moisturise; 4 daytime SPF; 5 save/share CTA. Cream background, sage accents, simple icons.  
**CTA:** Save this post

## Day 2 — Your routine, your way
**Format:** Story  
**Content pillar:** Community  
**Caption:** Quick poll: What’s the hardest part of a skincare routine? A) Knowing what to use B) Remembering to do it C) Keeping it simple  
**Creative direction:** Three story frames with poll sticker; calm neutral background.  
**CTA:** Vote in the poll

## Day 3 — A 30-second reset
**Format:** Reel thumbnail  
**Content pillar:** Lifestyle  
**Caption:** A tiny reset for a busy day: wash your face, moisturise, take a breath. Skincare can be a moment for you—not another task on your list.  
**Creative direction:** Reel cover: close-up of water, towel, and plant; headline “Your 30-second reset”.  
**CTA:** Share with a friend

## Day 4 — Meet Bloom & Bare
**Format:** Single image  
**Content pillar:** Brand story  
**Caption:** We believe skincare should feel approachable, not overwhelming. Bloom & Bare is built around simple steps, thoughtful choices, and routines that fit real life.  
**Creative direction:** Minimal brand introduction; logo wordmark and three brand values.  
**CTA:** Follow for simple skincare

## Day 5 — Myth: more products = better
**Format:** Carousel  
**Content pillar:** Education  
**Caption:** More steps don’t automatically mean a better routine. Start with the basics, introduce one new product at a time, and pay attention to how your skin responds. If irritation persists, consult a qualified professional.  
**Creative direction:** Five slides: myth; reality; start with basics; introduce slowly; save reminder.  
**CTA:** Save for your next shop

## Day 6 — This or that
**Format:** Story  
**Content pillar:** Community  
**Caption:** Choose your wind-down ritual: 🌙 early night or 📖 a few pages of a book?  
**Creative direction:** Two-frame story with poll sticker.  
**CTA:** Tap to vote

## Day 7 — Build a shelf you’ll use
**Format:** Reel thumbnail  
**Content pillar:** Lifestyle  
**Caption:** A simple routine shelf: keep everyday essentials visible, store products as directed, and skip anything you don’t use. Less clutter, less guesswork.  
**Creative direction:** Reel cover with tidy shelf; headline “Keep it simple”.  
**CTA:** Comment your must-have

## Day 8 — How to layer a basic routine
**Format:** Carousel  
**Content pillar:** Education  
**Caption:** A simple starting order: cleanse, apply suitable treatment if you use one, moisturise; in the morning, finish with broad-spectrum SPF. Product directions vary, so follow the label.  
**Creative direction:** Four slides with numbered steps and a morning note.  
**CTA:** Save this order

## Day 9 — Ingredient spotlight: aloe
**Format:** Single image  
**Content pillar:** Education  
**Caption:** Aloe is commonly used in skincare for its soothing feel. Formulas differ, and any ingredient can bother some people—patch test new products and stop if irritation occurs.  
**Creative direction:** Ingredient-inspired botanical photo; short factual copy.  
**CTA:** What ingredient should we explain next?

## Day 10 — Ask us anything
**Format:** Story  
**Content pillar:** Community  
**Caption:** What makes skincare confusing? Drop your question and we’ll answer with simple, practical guidance.  
**Creative direction:** Question sticker on sage background.  
**CTA:** Send a question

## Day 11 — A kinder routine checklist
**Format:** Carousel  
**Content pillar:** Education  
**Caption:** ☐ Cleanse gently ☐ Moisturise ☐ Use daytime SPF ☐ Introduce new products one at a time ☐ Give your routine time. Your skin doesn’t need to look like anyone else’s.  
**Creative direction:** Checklist carousel with large readable type and tick boxes.  
**CTA:** Save your checklist

## Day 12 — Pack a weekend routine
**Format:** Reel thumbnail  
**Content pillar:** Lifestyle  
**Caption:** Taking a short trip? Bring the basics you actually use, keep products in suitable containers, and follow storage instructions. No need to pack your entire shelf.  
**Creative direction:** Reel cover: small toiletry bag and essentials; headline “The simple travel kit”.  
**CTA:** Send to your travel buddy

## Day 13 — Small ritual, big pause
**Format:** Single image  
**Content pillar:** Lifestyle  
**Caption:** Take one quiet minute today: set your phone down, breathe, and do one small thing for yourself. A routine should support your day—not compete with it.  
**Creative direction:** Warm sunlight, linen, botanical detail; no product performance claims.  
**CTA:** Share your small ritual

## Day 14 — Your beginner routine FAQ
**Format:** Carousel  
**Content pillar:** Education  
**Caption:** Do I need lots of steps? No. Should I add everything at once? No—introduce products gradually. Do I need SPF in the daytime? Broad-spectrum sunscreen is an important part of sun protection. Follow product labels and professional advice.  
**Creative direction:** FAQ carousel with one question per slide.  
**CTA:** Save or share with a beginner

## Day 15 — Get the beginner’s guide
**Format:** Single image  
**Content pillar:** Conversion  
**Caption:** Ready to keep things simple? Get our free beginner routine guide with a clear checklist and space to build a routine that suits you.  
**Creative direction:** Simple graphic mockup of a guide cover with a signup CTA.  
**CTA:** Visit the link in bio

## Suggested hashtag bank
Use 3–6 relevant tags per post and rotate them rather than pasting the same block every time:
#SimpleSkincare #SkincareRoutine #MindfulSelfCare #BeginnerSkincare #DailyRitual #BloomAndBare

## Accessibility checklist
- Add accurate captions to reels.
- Use alt text for meaningful images.
- Keep text large and high-contrast.
- Avoid putting essential information only inside an image.
